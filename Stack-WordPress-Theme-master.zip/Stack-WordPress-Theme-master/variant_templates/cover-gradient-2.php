<!--META--><section class="vim" id="variant-cover-gradient-2" vbr="Cover Gradient 2" vbp="covers">
<section class="cover imagebg height-80 text-center" data-gradient-bg="#4876BD,#5448BD,#8F48BD,#BD48B1">
	<div class="background-image-holder background--top">
		<img alt="background" src="<?php variant_page_builder_demo_img('cowork-1.jpg'); ?>" />
	</div>
	<div class="container pos-vertical-center">
		<div class="row">
			<div class="col-sm-9 col-md-7">
				<div class="wysiwyg">
					<h1>Build stylish, lean sites with Stack</h1>
					<p class="lead">Stack offers a clean and contemporary look to suit a range of purposes from corporate, tech startup, marketing site to digital storefront.</p>
				</div>
				<a class="btn btn--primary type--uppercase" href="#">
					<span class="btn__text">
						View The Demos
					</span>
				</a>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->