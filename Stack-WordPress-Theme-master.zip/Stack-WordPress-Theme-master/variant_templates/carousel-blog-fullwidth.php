<!--META--><section class="vim" id="variant-carousel-blog-fullwidth" vbr="Carousel Blog Fullwidth" vbp="carousel">
<section class="unpad--top unpad--bottom">
	<div class="variant-shortcode" data-shortcode-name="stack_post" data-param-layout="carousel" data-param-pppage="6" data-param-filter="all" data-param-arrows="true" data-param-paging="false" data-param-timing="false"></div>
</section>
</section><!--end of meta Section container-->