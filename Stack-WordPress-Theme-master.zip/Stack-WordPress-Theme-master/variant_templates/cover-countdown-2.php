<!--META--><section class="vim" id="variant-cover-countdown-2" vbr="Cover Countdown 2" vbp="covers">
<section class="imagebg height-100 text-center" data-gradient-bg="#5f2c82,#49a09d,#F3A183,#5f2c82">
	<div class="background-image-holder"><img alt="background" src="<?php variant_page_builder_demo_img('inner-4.jpg'); ?>"></div>
	<div class="container pos-vertical-center">
		<div class="row">
			<div class="col-sm-9">
				<img alt="Image" src="<?php variant_page_builder_demo_img('headline-3.png'); ?>">
				<span class="h1 countdown variant-not-editable-mrv" data-date="05/25/2017" data-date-fallback="Launching Soon" data-days-text="days"></span>
				<div class="wysiwyg">
					<p class="lead">
						Themeforest's most popular HTML page builder comes to WordPress, 100+ page themes,<br class="hidden-xs hidden-sm"> 150+ unique blocks, premium plugins and icons, plus much more.
					</p>
				</div>
				<div class="modal-instance vog">
					<a class="modal-trigger btn btn--primary type--uppercase vog" href="#">
						<span class="btn__text">
							Notify Me
						</span>
					</a>
					<div class="modal-container vog">
						<div class="modal-content imagebg text-center vog">
							<div class="container">
						        <div class="row">
						            <div class="wysiwyg"><h2>Get notified as soon as we launch!</h2></div>
						            <div class="cf7-holder">
						            	<div class="variant-shortcode vru" data-shortcode-name="contact-form-7" data-param-title="" data-param-id="none">
						            		<p class="lead">Manage this form using the section sidebar <i class="material-icons">&#xE5C8;</i></p>
						            	</div>
						            </div>
						        </div><!--end of row-->
						    </div><!--end of container-->
						</div>
					</div><!--end modal container-->
				</div><!--end modal instance-->
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->