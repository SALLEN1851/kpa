<!--META--><section class="vim" id="variant-cover-text-1" vbr="Cover Text 1" vbp="covers">
<section class="cover height-80 imagebg text-center" data-overlay="3">
	<div class="background-image-holder">
		<img alt="background" src="<?php variant_page_builder_demo_img('landing-3.jpg'); ?>">
	</div>
	<div class="container pos-vertical-center">
		<div class="row">
			<div class="col-sm-12">
				<div class="wysiwyg"><h1>
					Streamline your workflow with Stack
				</h1></div>
				<a class="btn btn--primary type--uppercase" href="#">
					<span class="btn__text">
						View The Demos
					</span>
				</a>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->