<!--META--><section class="vim" id="variant-cover-text-4" vbr="Cover Text 4" vbp="covers">
<section class="imageblock switchable height-100">
    <div class="imageblock__content col-md-6 col-sm-4 pos-right">
        <div class="background-image-holder">
            <img alt="image" src="<?php variant_page_builder_demo_img('inner-7.jpg'); ?>">
        </div>
    </div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-md-5 col-sm-7">
            	<div class="wysiwyg">
	                <h1>Streamline your workflow with Stack</h1>
	                <p class="lead">
	                	Stack offers a clean and contemporary look to suit a range of purposes from corporate, tech startup, marketing site to digital storefront.
	                </p>
                </div>
                <a class="btn btn--primary type--uppercase" href="#">
					<span class="btn__text">
						View The Demos
					</span>
				</a>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->