<!--META--><section class="vim" id="variant-cta-horizontal-2-gradient" vbr="CTA Horizontal 2 Gradient" vbp="CTA">
<section class=" imagebg" data-gradient-bg="#4876BD,#5448BD,#8F48BD,#BD48B1">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="cta cta-1 cta--horizontal boxed boxed--border text-center-xs">
                    <div class="col-md-3 col-md-offset-1">
                        <h4>Let's get you started</h4>
                    </div>
                    <div class="col-md-4">
                        <p class="lead">
                            Start building pages in your browser
                        </p>
                    </div>
                    <div class="col-md-4 text-center">
                        <a class="btn btn--primary type--uppercase" href="#">
                            <span class="btn__text">
                                Try Builder
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->