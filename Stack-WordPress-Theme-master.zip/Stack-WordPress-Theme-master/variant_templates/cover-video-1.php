<!--META--><section class="vim" id="variant-cover-video-1" vbr="Cover Video 1" vbp="covers">
<section class="cover height-80 imagebg text-center" data-overlay="4">
	<div class="background-image-holder">
		<img alt="background" src="<?php variant_page_builder_demo_img('education-1.jpg'); ?>">
	</div>
	<div class="container pos-vertical-center">
		<div class="row">
			<div class="col-sm-8">
				<div class="wysiwyg">
					<h1>
						Build stylish, lean sites with Stack
					</h1>
					<p class="lead">
						Stack offers a clean and contemporary look to suit a range of purposes from corporate, tech startup, marketing site to digital storefront.
					</p>
				</div>
				<div class="modal-instance block vog">
					<div class="video-play-icon video-play-icon--sm modal-trigger vog"></div>
					<span><strong>See Stack in action</strong>&nbsp;&nbsp;&nbsp;104 Seconds</span>
					<div class="modal-container vog">
						<div class="modal-content bg-dark vog" data-width="60%" data-height="60%">
							<iframe allowfullscreen="allowfullscreen" no-src="https://www.youtube.com/embed/6p45ooZOOPo?autoplay=1"></iframe>
						</div><!--end of modal-content-->
					</div><!--end of modal-container-->
				</div><!--end of modal instance-->
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->