<!--META--><section class="vim" id="variant-cta-avatar-1" vbr="CTA Avatar 1" vbp="CTA">
<section class="text-center unpad--bottom switchable cta cta-3 ">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-7">
                <div class="switchable__text">
                	<div class="wysiwyg">
	                    <h2>Streamline your workflow with Stack</h2>
	                    <p class="lead">
	                        Create the smart, stylish site your business deserves.
	                    </p>
                    </div>
                    <a class="btn btn--primary type--uppercase" href="#purchase-template">
                        <span class="btn__text">
                            Purchase Stack Now
                        </span>
                        <span class="label">$59 USD</span>
                    </a>
                </div>
            </div>
            <div class="col-sm-6 col-md-5">
                <img alt="Image" class="block" src="<?php variant_page_builder_demo_img('avatar-large-1.png'); ?>">
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->