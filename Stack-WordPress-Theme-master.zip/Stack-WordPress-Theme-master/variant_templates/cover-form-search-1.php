<!--META--><section class="vim" id="variant-cover-form-search-1" vbr="Cover Form Search 1" vbp="covers">
<section class="cover imagebg height-70 text-center" data-overlay="4">
	<div class="background-image-holder"><img alt="background" src="<?php variant_page_builder_demo_img('knowledge-1.jpg'); ?>"></div>
	<div class="container pos-vertical-center">
		<div class="row">
			<div class="col-sm-10 col-md-8">
				<div class="wysiwyg">
					<h1>Stack Knowledgebase</h1>
					<p class="lead">
						A fully documented resource for developers using Stack in their web projects.
					</p>
				</div>
				<div class="boxed boxed--lg bg--white text-left">
					<div class="variant-shortcode" data-shortcode-name="stack_search_bar"></div>
				</div>
			</div>
		</div><!--end of row-->
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->