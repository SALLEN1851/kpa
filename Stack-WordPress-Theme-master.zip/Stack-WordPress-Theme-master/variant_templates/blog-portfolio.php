<!--META--><section class="vim" id="variant-blog-portfolio" vbr="Blog Portfolio" vbp="blog">
<section class="space--sm">
	<div class="container">
		<div class="variant-shortcode" data-shortcode-name="stack_post" data-param-layout="portfolio" data-param-pppage="6" data-param-filter="all" data-param-tags="all" data-param-offset="0"></div>
	</div><!--end of container-->
</section>
</section><!--end of meta Section container-->