<!--META--><section class="vim" id="variant-comments-1" vbr="Comments 1" vbp="blog">
<section class=" ">
    
    <div class="container">
        <div class="variant-shortcode" data-shortcode-name="stack_comments"></div>
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->