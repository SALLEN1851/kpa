<!--META--><section class="vim" id="variant-carousel-portfolio-2" vbr="Carousel Portfolio 2" vbp="carousel">
<section class=" ">
    
    <div class="container">
        <div class="variant-shortcode" data-shortcode-name="stack_portfolio" data-param-layout="carousel-2" data-param-pppage="6" data-param-filter="all" data-param-arrows="false" data-param-paging="true" data-param-timing="false"></div>
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->