<!--META--><section class="vim" id="variant-cover-video-5" vbr="Cover Video 5" vbp="covers">
<section class="cover height-100 text-center imagebg" data-overlay="1">
	<div class="background-image-holder"><img alt="background" src="<?php variant_page_builder_demo_img('landing-13.jpg'); ?>"></div>
    <div class="container pos-vertical-center">
        <div class="row">
            <div class="col-sm-12">
                <div class="wysiwyg"><h1>Your landing page. Reinvented.</h1></div>
                <div class="modal-instance block vog">
                    <div class="video-play-icon modal-trigger vog"></div>
                    <div class="modal-container vog">
                        <div class="modal-content bg-dark vog" data-width="60%" data-height="60%">
                            <iframe allowfullscreen="allowfullscreen" no-src="https://www.youtube.com/embed/6p45ooZOOPo?autoplay=1"></iframe>
                        </div><!--end of modal-content-->
                    </div><!--end of modal-container-->
                </div><!--end of modal instance-->
                <a class="btn btn--primary type--uppercase" href="#purchase-template">
                    <span class="btn__text">
                        Purchase Now
                    </span>
                </a>
                <div class="wysiwyg"><span class="block type--fine-print">or <a href="/">view the demos</a></span></div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->