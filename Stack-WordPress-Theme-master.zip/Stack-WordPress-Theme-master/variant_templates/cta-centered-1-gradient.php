<!--META--><section class="vim" id="variant-cta-centered-1-gradient" vbr="CTA Centered 1 Gradient" vbp="CTA">
<section class="text-center imagebg" data-gradient-bg="#4876BD,#5448BD,#8F48BD,#BD48B1">
    
    <div class="container">
        <div class="row">
            <div class="col-sm-8 col-md-6">
                <div class="cta">
                    <div class="wysiwyg">
                        <h2>Purchase Stack now and get lifetime free content updates</h2>
                        <p class="lead">
                            Each purchase of Stack comes with six months free support — and a lifetime of free content and bug-fix updates.
                        </p>
                    </div>
                    <a class="btn btn--primary type--uppercase" href="#purchase-template">
                        <span class="btn__text">
                            Purchase on Envato
                        </span>
                        <span class="label">$59 USD</span>
                    </a>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->