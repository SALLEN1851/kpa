<!--META--><section class="vim" id="variant-carousel-portfolio-1" vbr="Carousel Portfolio 1" vbp="carousel">
<section class="text-center ">
    
    <div class="container">
        <div class="variant-shortcode" data-shortcode-name="stack_portfolio" data-param-layout="carousel-1" data-param-pppage="6" data-param-filter="all" data-param-arrows="false" data-param-paging="true" data-param-timing="false"></div>
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->