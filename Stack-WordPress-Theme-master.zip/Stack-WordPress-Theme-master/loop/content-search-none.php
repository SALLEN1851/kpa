<div class="row">
	<div class="col-md-6 col-md-offset-3 text-center">
		<h3><?php esc_html_e( 'No search results found', 'stack' ); ?></h3>
		<?php echo get_search_form(); ?>
	</div>
</div>