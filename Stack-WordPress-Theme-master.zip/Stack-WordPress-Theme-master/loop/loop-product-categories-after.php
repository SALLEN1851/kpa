					</div><!--end masonry container-->
				</div><!--end of row-->
			</div><!--end masonry-->
		</div>
	</div><!--end of row-->
</section>