<div class="footer-stack-copyright">
	<?php echo wp_kses_post(get_option('stack_footer_copyright', '<span class="type--fine-print"><a href="http://www.tommusrhodus.com">Stack Premium WordPress Theme by TommusRhodus</a></span>')); ?>
</div>